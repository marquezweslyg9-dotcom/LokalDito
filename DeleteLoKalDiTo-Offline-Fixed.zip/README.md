# LoKalDiTo Offline APK Project

This is a self-contained Android WebView app. The HTML app is bundled in `app/src/main/assets/index.html` and uses no external web resources.

If uploading the project as a ZIP to GitHub, the GitHub Actions workflow should extract it before running Gradle.
