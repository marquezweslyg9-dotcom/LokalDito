# LoKalDiTo Offline Android App

This package is a standalone offline WebView app. The HTML is bundled at `app/src/main/assets/index.html` and does not depend on Jotform, a website, a database, or external CDNs.

For the ZIP-only GitHub workflow, upload this ZIP to the repository and use the included `.github/workflows/build-apk.yml` as the workflow content. The workflow refuses to report success unless the generated APK contains `assets/index.html`.


## App icon
The launcher icon uses the user-provided local market photo bundled in mipmap resources.
