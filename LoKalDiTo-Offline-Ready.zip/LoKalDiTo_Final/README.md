# LoKalDiTo Offline Android App

Standalone offline prototype based on the Canva Code shown in the screen recording. No Jotform, external database, Google Maps, CDN, or internet connection is required.

## Build
Push this project to a GitHub repository. Actions will build `app-debug.apk` and attach it to the workflow run as an artifact.
